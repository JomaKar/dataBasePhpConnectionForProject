-- phpMyAdmin SQL Dump
-- version 4.6.5.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 31-03-2017 a las 18:27:32
-- Versión del servidor: 5.6.34
-- Versión de PHP: 7.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `recipes`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ingredients`
--

CREATE TABLE `ingredients` (
  `id` int(11) NOT NULL,
  `name` varchar(120) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `amount_price` varchar(50) DEFAULT NULL,
  `imgPath` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `ingredients`
--

INSERT INTO `ingredients` (`id`, `name`, `price`, `amount_price`, `imgPath`) VALUES
(1, 'Sidras', 135, 'liter', './assets/images/ingredients/Sidras.jpg'),
(2, 'Licores', 251, 'liter', './assets/images/ingredients/Licores.jpg'),
(3, 'Vino blanco', 135, 'liter', './assets/images/ingredients/Vino blanco.jpg'),
(4, 'Vino caliente', 243, 'liter', './assets/images/ingredients/Vino caliente.jpg'),
(5, 'Vino tinto', 121, 'liter', './assets/images/ingredients/Vino tinto.jpg'),
(6, 'Vino rosado', 142, 'liter', './assets/images/ingredients/Vino rosado.jpg'),
(7, 'Whisky', 156, 'liter', './assets/images/ingredients/Whisky.jpg'),
(8, 'Aceite', 16, 'liter', './assets/images/ingredients/Aceite.jpg'),
(9, 'Crema', 26, 'liter', './assets/images/ingredients/Crema.jpeg'),
(10, 'Yogur', 29, 'liter', './assets/images/ingredients/Yogur.jpg'),
(11, 'Leche', 18, 'liter', './assets/images/ingredients/Leche.jpg'),
(12, 'Helado', 28, 'liter', './assets/images/ingredients/Helado.jpg'),
(13, 'Cervezas', 21, 'liter', './assets/images/ingredients/Cervezas.jpg'),
(14, 'Cafés', 22, 'liter', './assets/images/ingredients/Café.jpeg'),
(15, 'Agua', 14, 'liter', './assets/images/ingredients/Agua.jpg'),
(16, 'Zumo', 25, 'liter', './assets/images/ingredients/Zumo.jpg'),
(17, 'Te', 30, 'liter', './assets/images/ingredients/Te.jpg'),
(18, 'Horchata', 11, 'liter', './assets/images/ingredients/Horchata.jpg'),
(19, 'Queso', 28, 'kg', './assets/images/ingredients/Queso.jpg'),
(20, 'Hongos', 21, 'kg', './assets/images/ingredients/Hongos.jpg'),
(21, 'Legumbres', 28, 'kg', './assets/images/ingredients/Legumbres.jpg'),
(22, 'Patata', 28, 'kg', './assets/images/ingredients/Patatas.jpg'),
(23, 'Lechugas', 25, 'kg', './assets/images/ingredients/Lechugas.jpg'),
(24, 'Alcachofa', 27, 'kg', './assets/images/ingredients/Alcachofa.jpg'),
(25, 'Berenjena', 28, 'kg', './assets/images/ingredients/Berenjena.jpg'),
(26, 'Brócoli', 15, 'kg', './assets/images/ingredients/Brócoli.jpg'),
(27, 'Calabaza', 24, 'kg', './assets/images/ingredients/Calabaza.jpg'),
(28, 'Cebolla', 24, 'kg', './assets/images/ingredients/Cebolla.jpg'),
(29, 'Tomate', 27, 'kg', './assets/images/ingredients/Tomate.jpg'),
(30, 'Zanahoria', 19, 'kg', './assets/images/ingredients/Zanahoria.jpg'),
(31, 'Espárrago', 16, 'kg', './assets/images/ingredients/Espárrago.jpg'),
(32, 'Espinaca', 26, 'kg', './assets/images/ingredients/Espinaca.jpg'),
(33, 'Maíz', 15, 'kg', './assets/images/ingredients/Maíz.png'),
(34, 'Pepino', 20, 'kg', './assets/images/ingredients/Pepino.jpg'),
(35, 'Pimiento', 27, 'kg', './assets/images/ingredients/Pimiento.jpg'),
(36, 'Aguacate', 16, 'kg', './assets/images/ingredients/Aguacate.jpg'),
(37, 'Mango', 12, 'kg', './assets/images/ingredients/Mango.jpg'),
(38, 'Durazno', 27, 'kg', './assets/images/ingredients/Durazno.jpeg'),
(39, 'Peras', 18, 'kg', './assets/images/ingredients/Peras.jpg'),
(40, 'Manzanas', 11, 'kg', './assets/images/ingredients/Manzanas.jpg'),
(41, 'Uvas', 25, 'kg', './assets/images/ingredients/Uvas.jpg'),
(42, 'Limón', 22, 'kg', './assets/images/ingredients/Limón.jpeg'),
(43, 'Mandarina', 23, 'kg', './assets/images/ingredients/Mandarina.jpg'),
(44, 'Naranja', 16, 'kg', './assets/images/ingredients/Naranja.jpg'),
(45, 'Piña', 18, 'kg', './assets/images/ingredients/Piña.jpg'),
(46, 'Sandía', 19, 'kg', './assets/images/ingredients/Sandía.jpg'),
(47, 'Harina', 12, 'kg', './assets/images/ingredients/Harina.jpg'),
(48, 'Pan', 19, 'piece', './assets/images/ingredients/Pan.jpg'),
(49, 'Arroz', 12, 'kg', './assets/images/ingredients/Arroz.jpg'),
(50, 'Pasta', 16, 'kg', './assets/images/ingredients/Pasta.jpeg'),
(51, 'Refresco de toronja', 10, 'litro', './assets/images/ingredients/refrescoDeToronja.jpg'),
(52, 'Chile piquín', 60, 'kg', './assets/images/ingredients/piquin.jpg'),
(53, 'Tequila', 300, 'litro', './assets/images/ingredients/Tequila.jpg'),
(54, 'Sal', 10, 'kg', './assets/images/ingredients/sal.png'),
(55, 'Jugo de Toronja', 30, 'litro', './assets/images/ingredients/jugoDeToronja.png'),
(56, 'Jugo de Limón', 30, 'litro', './assets/images/ingredients/jugoDeLimón.jpg'),
(57, 'Hielo', 10, 'kg', './assets/images/ingredients/hielo.jpg'),
(58, 'Mezcal', 200, 'litros', './assets/images/ingredients/mezcal.jpg'),
(59, 'Agua mineral', 17, 'litros', './assets/images/ingredients/aguaMinerla.jpg'),
(60, 'Chocolate en polvo', 20, 'kg', './assets/images/ingredients/chocolateEnPolvo.jpg'),
(61, 'Salsa de chile', 20, 'litro', './assets/images/ingredients/salsaPicante.jpg'),
(62, 'Azúcar', 10, 'kg', './assets/images/ingredients/azucar.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recipes`
--

CREATE TABLE `recipes` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `imgPath` varchar(300) DEFAULT NULL,
  `description` text,
  `popularity` int(11) DEFAULT NULL,
  `ingredients` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `recipes`
--

INSERT INTO `recipes` (`id`, `name`, `imgPath`, `description`, `popularity`, `ingredients`) VALUES
(1, 'Paloma de tequila', './assets/images/recipes/paloma.jpg', 'Deliciosa bebida a base de tequila.\\nPreparación:\\n1. Mezcla partes iguales de sal y sazonador de fruta en un plato plano. Humedece la boca de un vaso con agua o jugo de limón y escarcha con la sal y sazonador. Llena el vaso con hielo.\\n2. Mezcla aparte el tequila con el jugo de toronja, jugo de limón y refresco de toronja. Vierte sobre el hielo en el vaso escarchado. ¡Disfruta!', 3, '[{\"ingredient\":{\"id\":\"54\",\"name\":\"Sal\",\"price\":\"10\",\"amount_price\":\"kg\",\"imgPath\":\"./assets/images/ingredients/sal.png\"},\"amount\":\"0.001\"},{\"ingredient\":{\"id\":\"52\",\"name\":\"Chile piquín\",\"price\":\"60\",\"amount_price\":\"kg\",\"imgPath\":\"./assets/images/ingredients/piquin.jpg\"},\"amount\":\"0.002\"},{\"ingredient\":{\"id\":\"55\",\"name\":\"Jugo de Toronja\",\"price\":\"30\",\"amount_price\":\"litro\",\"imgPath\":\"./assets/images/ingredients/jugoDeToronja.png\"},\"amount\":\"0.060\"},{\"ingredient\":{\"id\":\"56\",\"name\":\"Jugo de Limón\",\"price\":\"30\",\"amount_price\":\"litro\",\"imgPath\":\"./assets/images/ingredients/jugoDeLimón.jpg\"},\"amount\":\"0.015\"},{\"ingredient\":{\"id\":\"53\",\"name\":\"Tequila\",\"price\":\"300\",\"amount_price\":\"litro\",\"imgPath\":\"./assets/images/ingredients/Tequila.jpg\"},\"amount\":\"0.045\"},{\"ingredient\":{\"id\":\"51\",\"name\":\"Refresco de toronja\",\"price\":\"10\",\"amount_price\":\"litro\",\"imgPath\":\"./assets/images/ingredients/refrescoDeToronja.jpg\"},\"amount\":\"0.030\"},{\"ingredient\":{\"id\":\"57\",\"name\":\"Hielo\",\"price\":\"10\",\"amount_price\":\"kg\",\"imgPath\":\"./assets/images/ingredients/hielo.jpg\"},\"amount\":\"0.01\"}]'),
(3, 'Sangría', './assets/images/recipes/sangria.jpg', 'Mezcla atractiva de frutas, vino y limón.\\nSe mezcla en una jarra de agua 2/3 de agua mineral por cada tercio de vino, se agregan frutas al gusto y tres limones por cada jarra.', 2, '[{\"ingredient\":{\"id\":\"5\",\"name\":\"Vino tinto\",\"price\":\"121\",\"amount_price\":\"liter\",\"imgPath\":\"./assets/images/ingredients/Vino tinto.jpg\"},\"amount\":1},{\"ingredient\":{\"id\":\"59\",\"name\":\"Agua mineral\",\"price\":\"17\",\"amount_price\":\"litros\",\"imgPath\":\"./assets/images/ingredients/aguaMinerla.jpg\"},\"amount\":\"2\"},{\"ingredient\":{\"id\":\"56\",\"name\":\"Jugo de Limón\",\"price\":\"30\",\"amount_price\":\"litro\",\"imgPath\":\"./assets/images/ingredients/jugoDeLimón.jpg\"},\"amount\":\"0.2\"},{\"ingredient\":{\"id\":\"44\",\"name\":\"Naranja\",\"price\":\"16\",\"amount_price\":\"kg\",\"imgPath\":\"./assets/images/ingredients/Naranja.jpg\"},\"amount\":1},{\"ingredient\":{\"id\":\"40\",\"name\":\"Manzanas\",\"price\":\"11\",\"amount_price\":\"kg\",\"imgPath\":\"./assets/images/ingredients/Manzanas.jpg\"},\"amount\":\"2\"},{\"ingredient\":{\"id\":\"45\",\"name\":\"Piña\",\"price\":\"18\",\"amount_price\":\"kg\",\"imgPath\":\"./assets/images/ingredients/Piña.jpg\"},\"amount\":\"0.1\"}]'),
(4, 'Leche con chocolate', './assets/images/recipes/lecheConChocolate.jpg', 'Deliciosa y simple mezcla de lecha con chocolate.\\nSe mezclan de 1 a 1.5 cucharadas de chocolate en una vaso de leche frío o caliente y listo!', 1, '[{\"ingredient\":{\"id\":\"60\",\"name\":\"Chocolate en polvo\",\"price\":\"20\",\"amount_price\":\"kg\",\"imgPath\":\"./assets/images/ingredients/chocolateEnPolvo.jpg\"},\"amount\":\"1\"},{\"ingredient\":{\"id\":\"11\",\"name\":\"Leche\",\"price\":\"18\",\"amount_price\":\"liter\",\"imgPath\":\"./assets/images/ingredients/Leche.jpg\"},\"amount\":1}]'),
(5, 'Michelada', './assets/images/recipes/michelada.jpg', 'Cerveza preparada al gusto.\\nSe baña con limón el borde de la boquilla de un tarro de cerveza y luego se sumerge ese borde en sal y chile piquín.\\nSe llena la base del tarro con una pulgada de limón y media de salsa. Se llena el tarro con cerveza. Prost!', 4, '[{\"ingredient\":{\"id\":\"61\",\"name\":\"Salsa de chile\",\"price\":\"20\",\"amount_price\":\"litro\",\"imgPath\":\"./assets/images/ingredients/salsaPicante.jpg\"},\"amount\":\"0.5\"},{\"ingredient\":{\"id\":\"54\",\"name\":\"Sal\",\"price\":\"10\",\"amount_price\":\"kg\",\"imgPath\":\"./assets/images/ingredients/sal.png\"},\"amount\":\"0.5\"},{\"ingredient\":{\"id\":\"52\",\"name\":\"Chile piquín\",\"price\":\"60\",\"amount_price\":\"kg\",\"imgPath\":\"./assets/images/ingredients/piquin.jpg\"},\"amount\":\"0.5\"},{\"ingredient\":{\"id\":\"13\",\"name\":\"Cervezas\",\"price\":\"21\",\"amount_price\":\"liter\",\"imgPath\":\"./assets/images/ingredients/Cervezas.jpg\"},\"amount\":\"5\"},{\"ingredient\":{\"id\":\"56\",\"name\":\"Jugo de Limón\",\"price\":\"30\",\"amount_price\":\"litro\",\"imgPath\":\"./assets/images/ingredients/jugoDeLimón.jpg\"},\"amount\":1}]'),
(6, 'Agua de limón', './assets/images/recipes/limonada.jpg', 'Agua hecha a base de limón.\\nCortar y echar el jugo de 5 limones, así como 6 cucharadas de azúcar en una jarra llena de agua, revolver y listo.', 0, '[{\"ingredient\":{\"id\":\"62\",\"name\":\"Azúcar\",\"price\":\"10\",\"amount_price\":\"kg\",\"imgPath\":\"./assets/images/ingredients/azucar.jpg\"},\"amount\":\"6\"},{\"ingredient\":{\"id\":\"15\",\"name\":\"Agua\",\"price\":\"14\",\"amount_price\":\"liter\",\"imgPath\":\"./assets/images/ingredients/Agua.jpg\"},\"amount\":1},{\"ingredient\":{\"id\":\"42\",\"name\":\"Limón\",\"price\":\"22\",\"amount_price\":\"kg\",\"imgPath\":\"./assets/images/ingredients/Limón.jpeg\"},\"amount\":\"5\"}]'),
(7, 'Naranjada', './assets/images/recipes/naranjada.jpg', 'Agua hecha a base de naranja.\\nSe cortan 5 naranjas y se vierte su jugo en una jarra de agua. Se añaden 5 cucharadas de azúcar y listo.', 1, '[{\"ingredient\":{\"id\":\"44\",\"name\":\"Naranja\",\"price\":\"16\",\"amount_price\":\"kg\",\"imgPath\":\"./assets/images/ingredients/Naranja.jpg\"},\"amount\":\"5\"},{\"ingredient\":{\"id\":\"62\",\"name\":\"Azúcar\",\"price\":\"10\",\"amount_price\":\"kg\",\"imgPath\":\"./assets/images/ingredients/azucar.jpg\"},\"amount\":\"5\"},{\"ingredient\":{\"id\":\"15\",\"name\":\"Agua\",\"price\":\"14\",\"amount_price\":\"liter\",\"imgPath\":\"./assets/images/ingredients/Agua.jpg\"},\"amount\":1}]'),
(8, 'Agua de horchata', './assets/images/recipes/horchata.jpg', 'Agua de horchata.\\nSe deja remojando medio kilo de arroz en agua por un día. Se licúa el arroz y se añade azúcar, 6 cucharas, en una jarra del agua con la que se remojó el arroz. Listo!', 0, '[{\"ingredient\":{\"id\":\"49\",\"name\":\"Arroz\",\"price\":\"12\",\"amount_price\":\"kg\",\"imgPath\":\"./assets/images/ingredients/Arroz.jpg\"},\"amount\":\"0.5\"},{\"ingredient\":{\"id\":\"15\",\"name\":\"Agua\",\"price\":\"14\",\"amount_price\":\"liter\",\"imgPath\":\"./assets/images/ingredients/Agua.jpg\"},\"amount\":1},{\"ingredient\":{\"id\":\"62\",\"name\":\"Azúcar\",\"price\":\"10\",\"amount_price\":\"kg\",\"imgPath\":\"./assets/images/ingredients/azucar.jpg\"},\"amount\":\"6\"}]'),
(9, 'Vino mexicano', './assets/images/recipes/sangriaConMezcal.jpg', 'Es una rica bebida hecha a partir de vino y mezcal. Primero, se debe realizar una sangría con vino, agua mineral y limón al gusto, 3 de agua por 1 de vino y un cuarto de limón por cada vaso. Se tiene medio vaso de sangría y se añade un poco de agua pura y mezcal de maracuyá.', 1, '[{\"ingredient\":{\"id\":\"42\",\"name\":\"Limón\",\"price\":\"22\",\"amount_price\":\"kg\",\"imgPath\":\"./assets/images/ingredients/Limón.jpeg\"},\"amount\":\"0.25\"},{\"ingredient\":{\"id\":\"15\",\"name\":\"Agua\",\"price\":\"14\",\"amount_price\":\"liter\",\"imgPath\":\"./assets/images/ingredients/Agua.jpg\"},\"amount\":1},{\"ingredient\":{\"id\":\"58\",\"name\":\"Mezcal\",\"price\":\"200\",\"amount_price\":\"litros\",\"imgPath\":\"./assets/images/ingredients/mezcal.jpg\"},\"amount\":1},{\"ingredient\":{\"id\":\"59\",\"name\":\"Agua mineral\",\"price\":\"17\",\"amount_price\":\"litros\",\"imgPath\":\"./assets/images/ingredients/aguaMinerla.jpg\"},\"amount\":\"1.5\"},{\"ingredient\":{\"id\":\"5\",\"name\":\"Vino tinto\",\"price\":\"121\",\"amount_price\":\"liter\",\"imgPath\":\"./assets/images/ingredients/Vino tinto.jpg\"},\"amount\":\"0.5\"}]');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recipe_ingredients`
--

CREATE TABLE `recipe_ingredients` (
  `id` int(11) NOT NULL,
  `id_ingredients` int(11) DEFAULT NULL,
  `id_recipe` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `ingredients`
--
ALTER TABLE `ingredients`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `recipes`
--
ALTER TABLE `recipes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `recipe_ingredients`
--
ALTER TABLE `recipe_ingredients`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `ingredients`
--
ALTER TABLE `ingredients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT de la tabla `recipes`
--
ALTER TABLE `recipes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT de la tabla `recipe_ingredients`
--
ALTER TABLE `recipe_ingredients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
